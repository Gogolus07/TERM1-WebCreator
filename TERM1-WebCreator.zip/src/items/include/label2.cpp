#include "label2.h"

Label2::Label2()
{

}

Spécification codage : C++

```cpp
void maFonction() 
{
    //Code
}
```

Tabulation : 4 espaces (blocs plus lisibles)
Attributs de classe : m_attr
